class HangpersonGame
attr_accessor :word
attr_accessor :guesses
attr_accessor :wrong_guesses
attr_accessor :count
attr_accessor :word_with_guesses
attr_accessor :remaintoguess

  def initialize(word)
	if word == nil
		raise ArgumentError.new("Invalid Argument")
	end
   @word = word.downcase
    @remaintoguess = @word.length
    tempword = ""
    for i in 0...@remaintoguess
	 tempword =  tempword +  "-"
    end 
     @word_with_guesses = tempword
    @guesses = ""
    @wrong_guesses = ""
    @count = 0
  end
  def check_win_or_lose
      if @remaintoguess == 0 and @count != 0
 	 return :win
      elsif  @wrong_guesses.length < 7
	 return :play
      elsif @wrong_guesses.length == 7
	return :lose
      end
end		
def word_with_guesses
    return @word_with_guesses
end    

def self.get_random_word
    require 'uri'
    require 'net/http'
    uri = URI('http://watchout4snakes.com/wo4snakes/Random/RandomWord')
    Net::HTTP.post_form(uri ,{}).body
end
  
def guess(new_guess)
	if new_guess =~ /[^A-Za-z]/ or new_guess == "" or new_guess == nil
	      raise ArgumentError.new("Invalid Argument")
	end
	  new_guess.downcase!
	if !(@word.include? new_guess)
      if @wrong_guesses == "" or @wrong_guesses[new_guess] == nil
          @wrong_guesses = @wrong_guesses + new_guess
			    @count = @count + 1 
	    elsif @wrong_guesses[new_guess] != nil
			    return false	
	    end	
	elsif @guesses == '' or @guesses[new_guess] == nil
		 @guesses =  new_guess 
	   @count = @count + 1
     for temp in 0...@word.length                
		    if @word[temp] == new_guess[0]
                  @word_with_guesses[temp] = @word[temp]
				  @remaintoguess = @remaintoguess - 1	
           end
      end		
	elsif @guesses[new_guess] != nil
	       return false 
	end
 end
end

