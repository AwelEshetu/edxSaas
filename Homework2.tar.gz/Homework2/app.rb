	require 'sinatra'
	class MyApp < Sinatra::Base
		get '/' do
			"<!DOCTYPE html><html><head></head><body><h1>Two most powerful weapons on earth</h1><ul><li>Language: For Abstraction.</li><li>Knowledge: For Distruction(creation :D)</li></ul></body></html>"
   		end
	end
